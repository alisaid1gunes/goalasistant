package com.alisaidgunes.goalassistant;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;


public class RewardAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    final private static int TYPE_REWARDS = 0;
    private Context ctx;
    public RewardAdapter(Context mctx) {
        this.ctx = mctx;
    }
public class  RewardViewHolder extends RecyclerView.ViewHolder{
        private CardView CardReward;
        private ProgressBar RewardProgress;
        private TextView ProgressCounter;
        private TextView Reward;
        private ImageView MenuImgReward;
    public RewardViewHolder(@NonNull View itemView) {
        super(itemView);
        CardReward = (CardView)itemView.findViewById(R.id.card_reward);
        RewardProgress  = (ProgressBar)itemView.findViewById(R.id.reward_progress);
        ProgressCounter = (TextView)itemView.findViewById(R.id.reward_counter);
        MenuImgReward = (ImageView)itemView.findViewById(R.id.menu_img_reward);
        Reward = (TextView)itemView.findViewById(R.id.reward);
    }
}
    @Override
    public int getItemCount() {
        return 20;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
switch (i){
    case TYPE_REWARDS:
        RewardViewHolder rewardViewHolder = (RewardViewHolder)viewHolder;
        rewardViewHolder.ProgressCounter.setText("10/20");
        rewardViewHolder.Reward.setText("Tatil");
        rewardViewHolder.RewardProgress.setMax(20);
        rewardViewHolder.RewardProgress.setProgress(10);
        rewardViewHolder.MenuImgReward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu = new PopupMenu(ctx, v);
                popupMenu.getMenu().add("Edit");
                popupMenu.show();

            }
        });
}
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
       RecyclerView.ViewHolder rv = null;
       switch (i){
           case TYPE_REWARDS:
               view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.reward_card_design,viewGroup,false);
               rv = new RewardViewHolder(view);
               break;
       }

        return rv;
    }

    @Override
    public int getItemViewType(int position) {
        int ReturnTypeReward = 0;

        switch (position){
            case 0:
                ReturnTypeReward = TYPE_REWARDS;
                break;
        }

        return ReturnTypeReward;
    }


}