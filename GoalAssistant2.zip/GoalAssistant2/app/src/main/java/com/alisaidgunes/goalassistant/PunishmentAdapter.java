package com.alisaidgunes.goalassistant;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

public class PunishmentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context ctx;
    final private static int TYPE_PUNISHMENT = 0;
    public PunishmentAdapter(Context mctx) {
        this.ctx = mctx;
    }
public class  PunishmentViewHolder extends RecyclerView.ViewHolder{
    private CardView CardPunishment;
    private ProgressBar PunishmentProgress;
    private TextView ProgressCounter;
    private TextView Punishment;
    private ImageView MenuImgPunishment;
    public PunishmentViewHolder(@NonNull View itemView) {
        super(itemView);
        CardPunishment = (CardView)itemView.findViewById(R.id.card_punishment);
        PunishmentProgress  = (ProgressBar)itemView.findViewById(R.id.punishment_progress);
        ProgressCounter = (TextView)itemView.findViewById(R.id.punishment_counter);
        MenuImgPunishment = (ImageView)itemView.findViewById(R.id.menu_img_punishment);
        Punishment = (TextView)itemView.findViewById(R.id.punishment);
    }
}
    @Override
    public int getItemCount() {
        return 20;
    }

    @Override
    public int getItemViewType(int position) {
        int ReturnTypePunishment = 0;

        switch (position){
            case 0:
                ReturnTypePunishment  = TYPE_PUNISHMENT;
                break;
        }

        return ReturnTypePunishment ;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        RecyclerView.ViewHolder rv = null;
        switch (i){
            case TYPE_PUNISHMENT:
                view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.punishment_card_design,viewGroup,false);
                rv = new PunishmentViewHolder(view);
                break;
        }

        return rv;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        switch (getItemViewType(i)){
            case TYPE_PUNISHMENT:
                PunishmentViewHolder pv = (PunishmentViewHolder)viewHolder;
                pv.ProgressCounter.setText("10/20");
                pv.Punishment.setText("Tatil");
                pv.PunishmentProgress.setMax(20);
                pv.PunishmentProgress.setProgress(10);
                pv.MenuImgPunishment.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        PopupMenu popupMenu = new PopupMenu(ctx, v);
                        popupMenu.getMenu().add("Edit");
                        popupMenu.show();

                    }
                });
                break;
        }
    }
}
