package com.alisaidgunes.goalassistant;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    final private static int TYPE_DAYS = 0;
    final private static int TYPE_AD = 1;
    final private static int TYPE_QUOTE = 2;
    final private static int TYPE_CHART = 3;

    final private static int TYPE_CLUE = 6;
    private Context ctx;

    public MyAdapter(Context mc) {
        this.ctx = mc;
    }

    public class ClueViewHolder extends RecyclerView.ViewHolder {
        private CardView cardclue;
        private TextView clue;
        private TextView titleclue;

        public ClueViewHolder(@NonNull View itemView) {
            super(itemView);
            cardclue = (CardView) itemView.findViewById(R.id.cluecard);
            clue = (TextView) itemView.findViewById(R.id.clue);
            titleclue = (TextView) itemView.findViewById(R.id.titleclue);
        }
    }





    public class QuotesViewHolder extends RecyclerView.ViewHolder {
        private CardView cardquote;
        private TextView quote;
        private TextView whosays;

        public QuotesViewHolder(@NonNull View itemView) {
            super(itemView);

            cardquote = (CardView) itemView.findViewById(R.id.quotecard);
            quote = (TextView) itemView.findViewById(R.id.quote);
            whosays = (TextView) itemView.findViewById(R.id.whosays);

        }
    }

    public class DaysViewHolder extends RecyclerView.ViewHolder {
        private CardView cardDays;
        private CalendarView calendarView;

        public DaysViewHolder(@NonNull View itemView) {
            super(itemView);
            cardDays = (CardView) itemView.findViewById(R.id.card_days);
            calendarView = (CalendarView) itemView.findViewById(R.id.calendar_view);

        }
    }

    public class AdViewHolder extends RecyclerView.ViewHolder {
        private CardView cardAd;

        public AdViewHolder(@NonNull View itemView) {
            super(itemView);
            cardAd = (CardView) itemView.findViewById(R.id.ads);
        }
    }

    public class ChartViewHolder extends RecyclerView.ViewHolder {
        private CardView cardChart;
        private GraphView graph;

        public ChartViewHolder(@NonNull View itemView) {
            super(itemView);
            cardChart = (CardView) itemView.findViewById(R.id.chart_card);
            graph = (GraphView) itemView.findViewById(R.id.graph);
        }
    }

    @Override
    public int getItemViewType(int position) {

        int ReturnType = 0;
        //    if(position==0){
        //      return TYPE_DAYS;
        // }
        //   else{

        //  return TYPE_AD;
        //}

        switch (position) {
            case 0:
                ReturnType = TYPE_DAYS;
                break;
            case 1:
                ReturnType = TYPE_AD;
                break;
            case 2:
                ReturnType = TYPE_QUOTE;
                break;
            case 3:
                ReturnType = TYPE_CHART;
                break;

            case 4:
                ReturnType = TYPE_CLUE;
        }


        return ReturnType;
    }

    @NonNull

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        RecyclerView.ViewHolder rv = null;


     /*  if (viewType==TYPE_DAYS){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.goaldays_card_design,parent,false);
           return   new DaysViewHolder(view);
        }
      else {

            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_ad_design,parent,false);
           return   new AdViewHolder(view);
        }
*/
        switch (viewType) {
            case TYPE_DAYS:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.goaldays_card_design, parent, false);
                rv = new DaysViewHolder(view);
                break;
            case TYPE_AD:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_ad_design, parent, false);
                rv = new AdViewHolder(view);
                break;
            case TYPE_QUOTE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_quote_design, parent, false);
                rv = new QuotesViewHolder(view);
                break;
            case TYPE_CHART:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chart_card_design, parent, false);
                rv = new ChartViewHolder(view);
                break;


            case TYPE_CLUE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_clue_design, parent, false);
                rv = new ClueViewHolder(view);
                break;
        }
        return rv;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
                 /*   if (getItemViewType(position)==TYPE_DAYS){
                        DaysViewHolder dv = (DaysViewHolder)holder;
                        List<EventDay> eventDays = new ArrayList<>();
                        Calendar calendar=Calendar.getInstance();

                        eventDays.add(new EventDay(calendar,R.mipmap.ic_launcher));
                        dv.calendarView.setEvents(eventDays);
                    }
                    else {
                        AdViewHolder av = (AdViewHolder)holder;

                    }
                    */
        switch (getItemViewType(position)) {
            case TYPE_DAYS:
                DaysViewHolder dv = (DaysViewHolder) holder;
                List<EventDay> eventDays = new ArrayList<>();
                Calendar calendar = Calendar.getInstance();

                eventDays.add(new EventDay(calendar, R.mipmap.ic_launcher));
                dv.calendarView.setEvents(eventDays);
                break;
            case TYPE_AD:
                AdViewHolder av = (AdViewHolder) holder;
                break;
            case TYPE_QUOTE:
                QuotesViewHolder qv = (QuotesViewHolder) holder;
                break;
            case TYPE_CHART:
                ChartViewHolder cv = (ChartViewHolder) holder;

                LineGraphSeries<DataPoint> series = new LineGraphSeries<>
                        (new DataPoint[]{
                                new DataPoint(0, 1),
                                new DataPoint(1, 5),
                                new DataPoint(2, 3),
                                new DataPoint(3, 2),
                                new DataPoint(4, 6)
                        });


                series.setColor(Color.argb(255, 233, 30, 99));
                cv.graph.addSeries(series);


                break;

            case TYPE_CLUE:
                ClueViewHolder clueViewHolder = (ClueViewHolder) holder;
                break;

        }
    }

    @Override
    public int getItemCount() {
        return 5;
    }
}
